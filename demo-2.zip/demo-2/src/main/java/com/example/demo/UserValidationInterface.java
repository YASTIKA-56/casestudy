package com.example.demo;

public interface UserValidationInterface {
	public boolean validateUser(String username, String password);
}
